
<?php $__env->startPush('head'); ?>
    <title>Dashboard | Register</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('active-tab'); ?>
<?php
  $register='active';
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dynamic-section'); ?>
<?php if(session()->has('Registration')): ?>
  <div class="alert alert-success alert-dismissible fade show mb-5" role="alert">
    <div class="container">
    <strong><?php echo e(session()->get('Registration')); ?></strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  </div>
  <?php endif; ?>
    <div class="h1 mt-4 text-center mb-5">Register Client</div>
    <form action="<?php echo e(route('dashboard.register')); ?>" method="post" class="row g-3 p-3">
        <?php echo csrf_field(); ?>
        <div class="col-11 mx-auto">
            <label for="inputAddress2" class="form-label">Name</label>
            <input type="text" class="form-control" placeholder="Enter the Client Name" name="Client_Name" value="<?php echo e(old('Client_Name')); ?>">
            <span class="text-danger">
                <?php $__errorArgs = ['Client_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
        </div>
        <div class="col-11 mx-auto">
            <label for="inputAddress" class="form-label">Phone Number</label>
            <input type="number" class="form-control" placeholder="+__ ___ _______" name="Client_Mobile" value="<?php echo e(old('Client_Mobile')); ?>">
            <span class="text-danger">
              <?php $__errorArgs = ['Client_Mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
        </div>
        <div class="col-md-5 mx-auto">
            <label for="inputEmail4" class="form-label">Country</label>
            <input type="text" class="form-control" placeholder="Country" name="Client_Country" value="<?php echo e(old('Client_Country')); ?>">
            <span class="text-danger">
              <?php $__errorArgs = ['Client_Country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
        </div>
        <div class="col-md-5 mx-auto">
            <label for="inputPassword4" class="form-label">City</label>
            <input type="text" class="form-control" placeholder="City" name="Client_City" value="<?php echo e(old('Client_City')); ?>">
            <span class="text-danger">
              <?php $__errorArgs = ['Client_City'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
        </div>


        <div class="col-md-5 mx-auto">
            <label for="inputCity" class="form-label">Email</label>
            <input type="email" class="form-control" placeholder="example@gmail.com" name="Client_Email" value="<?php echo e(old('Client_Email')); ?>">
            <span class="text-danger">
              <?php $__errorArgs = ['Client_Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
        </div>
        <div class="col-md-5 mx-auto">
            <label for="inputCity" class="form-label">Password</label>
            <input type="password" class="form-control" placeholder="Set Client Password" name="Client_Password">
            <span class="text-danger">
              <?php $__errorArgs = ['Client_Password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
        </div>


        <div class="col-11 mx-auto mt-4">
            <button type="submit" class="btn btn-primary btn-lg">Register Client</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel project\Paid-Laravel-projects\QKCreators\resources\views/dashboard/register.blade.php ENDPATH**/ ?>