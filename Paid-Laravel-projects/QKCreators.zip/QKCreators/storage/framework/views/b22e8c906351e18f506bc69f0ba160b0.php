<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Send Quotes</title>
  <style>
    table,th,td{
padding: 1rem;
text-align: left;
    }
    .card{
      
      border-radius: 5px;
      border: 0.5px solid rgba(0, 0, 0, 0.507);
      width:85% ;
      margin: 1rem auto 0;
      padding: 2rem;
    }
    button{
      padding: 0.5rem 1.2rem;
      border: none;
      border-radius: 5px;
      color: white;
    }
  </style>
</head>
<body>
  <div class="card">
  <p>Name: <b><?php echo e($mailData['client_name']); ?></b></p>
  <p>Request Title: <b><?php echo e($mailData['request_title']); ?></b></p>
  <p>Request Deadline: <b> <?php echo e($mailData['request_deadline']); ?></b></p>
  <table style="width: 100%;max-width:800px;margin: 0.5rem auto">
    <tr style="background-color: rgb(9, 49, 212);color:white">
      <th>Sr.No.</th>
      <th>LineItems</th>
      <th>Prices</th>
    </tr>
    <?php
      $sr_no=1;
    ?>
    <?php $__currentLoopData = $mailData['invoice']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($sr_no); ?></td>
      <td><?php echo e($item['line_items']); ?></td>
      <td><?php echo e($item['price']); ?>$</td>
    </tr>
    <?php
      $sr_no+=1;
    ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr style="background-color: rgb(8, 158, 8);color:white">
      <th>Total</th>
     
      <th colspan="2"><?php echo e($mailData['total']); ?>$</th>
    </tr>
  </table>
  <p><big>You can Accept Quotes to Start Job and also can Reject Quotes to Cancel Project Request</big></p>
  <div>
    <a href="http://127.0.0.1:8000/api/acceptQuote/<?php echo e($mailData['request_id']); ?>"><button style="background-color: rgb(25, 187, 25)">Accept</button></a>
    <a href="http://127.0.0.1:8000/api/rejectQuote/<?php echo e($mailData['request_id']); ?>"><button style="background-color: rgb(212, 29, 29)">Reject</button></a>
  </div>
</div>
  <br>
  <br>
  <br>
  <br>
  <br>
</body>
</html><?php /**PATH D:\laravel project\Paid-Laravel-projects\QKCreators\resources\views/emails/sendQuote.blade.php ENDPATH**/ ?>