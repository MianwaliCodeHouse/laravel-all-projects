
<?php $__env->startPush('head'); ?>
  <title>Dashboard | Request</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('active-tab'); ?>
<?php
  $create_request='active';
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dynamic-section'); ?>
<?php if(session()->has('ClientRequestSent')): ?>
<div class="alert alert-success alert-dismissible fade show mb-5" role="alert">
  <div class="container">
  <strong><?php echo e(session()->get('ClientRequestSent')); ?></strong>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
</div>
<?php endif; ?>
  <div class="h1 mt-4 mb-3">Create Request</div>
  <div class="card">
    <div class="card-body">

    
  <form action="<?php echo e(route('client.request')); ?>" method="post" enctype="multipart/form-data" class="row g-3 p-3">
      <?php echo csrf_field(); ?>
      <div class="col-md-5 mx-auto">
          <label for="inputAddress2" class="form-label">Request Title<sup>*</sup></label>
          <input type="text" class="form-control" placeholder="Type Request Title" name="request_title" value="<?php echo e(old('request_title')); ?>">
          <span class="text-danger">
              <?php $__errorArgs = ['request_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
      </div>
      <div class="col-md-5 mx-auto">
          <label for="inputAddress2" class="form-label">Your Deadline</label>
          <input type="date" class="form-control" name="request_deadline" value="<?php echo e(old('request_deadline')); ?>">
          
      </div>
      <div class="col-11 mx-auto">
          <label for="inputAddress" class="form-label">Request Requirements<sup>*</sup></label>
          <textarea class="form-control" rows="3" name="request_requirements" placeholder="Type Requirements"><?php echo e(old('request_requirements')); ?></textarea>
          <span class="text-danger">
            <?php $__errorArgs = ['request_requirements'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
      </div>
      <div class="col-md-5 mx-auto">
          <label for="inputEmail4" class="form-label">Your Budget</label>
          <input type="text" class="form-control" placeholder="___$" name="request_budget" value="<?php echo e(old('request_budget')); ?>">
          
      </div>
      <div class="col-md-5 mx-auto">
          <label for="inputPassword4" class="form-label">Project Type<sup>*</sup></label>
          <select class="form-select" aria-label="Default select example" name="project_type">
            <option value="">Choose Project Type</option>
            <option value="New Project">New Project</option>
            <option value="Change in Existing Project">Change in Existing Project</option>
            <option value="Bug in Existing Project">Bug in Existing Project</option>
          </select>
          <span class="text-danger">
            <?php $__errorArgs = ['project_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
      </div>


      <div class="col-11 mx-auto">
        <label for="inputAddress2" class="form-label">Attachments</label>
        <input type="file" class="form-control" name="attachments[]" multiple>
    </div>


      <div class="col-11 mx-auto mt-4">
          <button type="submit" class="btn btn-primary btn-lg">Submit</button>
      </div>
  </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel project\Paid-Laravel-projects\QKCreators\resources\views/createRequest.blade.php ENDPATH**/ ?>