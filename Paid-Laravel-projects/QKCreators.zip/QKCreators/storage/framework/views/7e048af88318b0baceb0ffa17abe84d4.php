
<?php echo $__env->yieldContent('active-tab'); ?>

<div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <div class="col-md-2 bg-dark text-light py-4">
        <h3 class="text-center mb-5">Admin Dashboard</h3>
        <a href="#" class="nav-link text-black py-2 px-4 <?=!empty($home)?'bg-primary text-white fw-bold':'bg-white' ?> rounded mb-3">Home</a>
        
        <a href="<?php echo e(route('dashboard.clientRequests')); ?>" class="nav-link text-black py-2 px-4 <?=!empty($requestRoute)?'bg-primary text-white fw-bold':'bg-white' ?> rounded mb-3">Requests</a>
        <a href="<?php echo e(route('admin.quote.display')); ?>" class="nav-link text-black py-2 px-4 <?=!empty($quotes)?'bg-primary text-white fw-bold':'bg-white' ?> rounded mb-3">Quotes</a>
        <a href="#" class="nav-link text-black py-2 px-4 <?=!empty($client)?'bg-primary text-white fw-bold':'bg-white' ?> rounded mb-3">Clients</a>
        <a href="<?php echo e(route('dashboard.registerForm')); ?>" class="nav-link text-black py-2 px-4 <?=!empty($register)?'bg-primary text-white fw-bold':'bg-white' ?> rounded mb-3">Register</a>
        
        <a href="<?php echo e(route('dashboard.logout')); ?>" class="nav-link text-white fw-bold py-2 px-4 bg-danger rounded mb-3">Logout</a>
        
      </div>
      <!-- Main Content Area -->
      <div class="col-md-10 py-4 overflow-auto vh-100">
        <?php echo $__env->yieldContent('dynamic-section'); ?>
      </div>
    </div>
  </div>

  
<?php /**PATH D:\laravel project\Paid-Laravel-projects\QKCreators\resources\views/dashboard/layouts/common.blade.php ENDPATH**/ ?>