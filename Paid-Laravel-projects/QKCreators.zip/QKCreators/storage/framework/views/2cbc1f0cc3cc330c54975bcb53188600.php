<!-- Modal -->
<div class="modal fade" id="quotes_builder" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Quotes Builder</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mt-2" id="SendMailAndSave">

                </div>

                
                <div class="p-3">
                    <div class="h3 mb-3 text-center">Create Entery</div>
                    <div class="row gap-3 mx-3">
                        <div class="col-10 col-md-5">
                            <input type="text" id="LineItem" class="form-control" placeholder="Enter Line item">
                        </div>
                        <div class="col-10 col-md-3">
                            <input type="number" id="Price" class="form-control" placeholder="Price">
                        </div>

                        <input type="number" id="request_id" value="" hidden>
                        <div class="col-10 col-md-3">
                            <button class="btn btn-dark" onclick="Add_Quotes_Line_item(request_id.value)">Add</button>
                        </div>
                        <div class="row gap-3 mt-2 mb-5">
                            <div class="col-10 col-md-3">
                                <input type="date" id="DeadlineDate" class="form-control">
                            </div>

                        </div>
                    </div>

                    
                    <div class="mt-2 bg-light p-3 mb-5">
                        <div class="h2 text-center mb-4">Invoice</div>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Line Item</th>
                                    <th>Price</th>

                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="InsertFetchData">

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="sndMail(request_id.value,this)">Save changes</button>

            </div>
        </div>
    </div>
</div>



<script>
    // Fetch Line Items 

    function fetchLineItems(id) {
        fetch(`http://127.0.0.1:8000/api/fetch/${id}`).then(
            r => {
                return r.json();
            }
        ).then(
            d => {
                let fetchDataVar='';
                for (let index = 0; index < d.length; index++) {
                    let sr_no=index+1;
                    fetchDataVar += `
            <tr>
                                <td>${sr_no}</td>
                                <td>${d[index]['line_items']}</td>
                                <td>${d[index]['price']}</td>
                                
                                <td>
                                    <button class="btn btn-danger btn-sm"
                                        onclick="Delete_Quotes_Line_item(${d[index]['id']})">Delete</button>
                                </td>
            </tr>`;


                }
                InsertFetchData.innerHTML=fetchDataVar;

            }
        )
    }


    // Add Line Item 
    function Add_Quotes_Line_item(request_id) {
        let RequestId = request_id;
        let LineItem = document.querySelector('#LineItem').value;
        let Price = document.querySelector('#Price').value;
        let status = false;
        fetch(
                `http://127.0.0.1:8000/api/addQuotesLineItem/?requestId=${RequestId}&&LineItem=${LineItem}&&Price=${Price}`)
            .then(
                r => {
                    return r.text();
                }
            ).then(
                d => {
                    if (d == '1') {
                        status = true;
                        if (status) {
                           
                            this.fetchLineItems(RequestId);
                        }
                        document.querySelector('#LineItem').value = '';
                        document.querySelector('#Price').value = '';
                    } else {
                        alert("plz fill both fields( Line Items and Price )")
                    }
                }
            )

    }


    // Delete LineItem 
    function Delete_Quotes_Line_item(requestId) {
        let RequestId=request_id.value;
        let status = false;
        fetch(`http://127.0.0.1:8000/api/DeleteQuotesLineItem/${requestId}`).then(
            r => {
                return r.text();
            }
        ).then(
            d => {
                console.log(d);
                if(d=='1'){
                    status = true;
                    if (status) {
                           
                        this.fetchLineItems(RequestId);
                    }
                }
            }
        )
    }

    // Send Mail 
    function sndMail(r_id,element){
        element.innerHTML=`Wait for Saving  <div class="spinner-border spinner-border-sm text-light" role="status">
  <span class="visually-hidden">Loading...</span>
</div>`;
        let deadline=DeadlineDate.value;
        fetch(`http://127.0.0.1:8000/api/SendMailInvoice/${r_id}/${deadline}`).then(
            r=>{
                return r.text();
            }
        ).then(
            d=>{
                console.log(d)
                if(d=='1'){
                    
                    SendMailAndSave.innerHTML=`<div class="alert alert-success alert-dismissible fade show mb-2" role="alert">
    <div class="container">
    <strong>Changes has been saved and also Sent Mail to Client to inform about Quote</strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  </div>`;
                  DeadlineDate.value='';
                  element.innerHTML='Saved Changes';
                }
            }
        )
    }
</script>
<?php /**PATH D:\laravel project\Paid-Laravel-projects\QKCreators\resources\views/dashboard/quotes_builder.blade.php ENDPATH**/ ?>