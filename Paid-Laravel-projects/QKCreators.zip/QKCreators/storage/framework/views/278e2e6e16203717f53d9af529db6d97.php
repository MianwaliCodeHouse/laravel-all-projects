
<?php $__env->startPush('head'); ?>
  <title>Dashboard | Home</title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('active-tab'); ?>
<?php
  $requestRoute='active';
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dynamic-section'); ?>
  


<?php $__currentLoopData = $AllRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<!-- Modal -->
<div class="modal fade" id="requirements<?php echo e($Request['request_id']); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Requirements</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo e($Request['request_requirements']); ?>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__currentLoopData = $AllRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<!-- Modal -->
<div class="modal fade" id="attachments<?php echo e($Request['request_id']); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Attachments</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php
          $attachments=$Request['attachments'];
          $attachments=explode(',,,',$attachments);
          array_pop($attachments);
        ?>
        <?php $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="h6">Document <?php echo e($key); ?></div>
          <a href="" class="mb-4 d-block"><?php echo e($value); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php echo $__env->make('dashboard.quotes_builder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="h1 mt-3 mb-3">Requests</div>
<div class="table-reponsive">
<table class="table table-hover w-sm-100">
  <thead class="table-dark">
  <tr>
    <th>Client Name</th>
    <th>Title</th>
    <th>DeadLine</th>
    <th>Project Type</th>
    <th>Requirements</th>
    <th>Attachments</th>
    <th>Status</th>
    <th>Actions</th>
  </tr>
</thead>
<?php $__currentLoopData = $AllRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr valign='middle'>
  <td><?php echo e($Request['client_name']); ?></td>
  <td><?php echo e($Request['request_title']); ?></td>
  <td><?php echo e($Request['request_deadline']); ?></td>
  <td><?php echo e($Request['project_type']); ?></td>
  <td><button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#requirements<?php echo e($Request['request_id']); ?>">Requirements</button></td>
  <td><button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#attachments<?php echo e($Request['request_id']); ?>">Attachments</button></td>
  <td><span class="bg-warning rounded px-2 py-1 d-inline-block"><?php echo e($Request['status']); ?></span></td>
  <td>
    <button class="btn btn-success btn-sm">View</button>
    <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#quotes_builder" onclick="document.querySelector('#request_id').value=<?php echo e($Request['request_id']); ?>;fetchLineItems(request_id.value);">Quotes</button>
    <button class="btn btn-success btn-sm">Job</button>
    <button class="btn btn-danger btn-sm">Reject</button>
  </td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
</table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel project\Paid-Laravel-projects\QKCreators\resources\views/dashboard/request.blade.php ENDPATH**/ ?>