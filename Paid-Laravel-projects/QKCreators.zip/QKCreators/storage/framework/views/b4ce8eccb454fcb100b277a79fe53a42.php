
<?php $__env->startPush('head'); ?>
  <title>Dashboard | Home</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('active-tab'); ?>
<?php
  $home='active';
?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dynamic-section'); ?>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel project\Paid-Laravel-projects\QKCreators\resources\views/index.blade.php ENDPATH**/ ?>