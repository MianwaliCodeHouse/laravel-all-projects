<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Admin Inform About Client Request</title>
</head>
<body>
  <h1>New Request from <?php echo e($mailData['name']); ?></h1>
  <p>You recieved a new Request</p>
  <p><big><b>Client Name: </b>         <?php echo e($mailData['name']); ?>    </big></p>
  <p><big><b>Request Title: </b>       <?php echo e($mailData['requestTitle']); ?>    </big></p>
  <p><big><b>Request Requirements: </b> <?php echo e($mailData['requestRequirements']); ?>   </big></p>
</body>
</html><?php /**PATH D:\laravel project\Paid-Laravel-projects\QKCreators\resources\views/emails/adminInfoAboutRequest.blade.php ENDPATH**/ ?>