
<?php $__env->startPush('head'); ?>
  <title>Dashboard | Quotes</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('active-tab'); ?>
<?php
  $quotes='active';
?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dynamic-section'); ?>
<?php echo $__env->make('Invoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
<h1 class="h1-responsive mb-3">Quotes</h1>

<table class="table table-striped">
  <thead class="table-dark">
    <th>Request Title</th>
    <th>Request Deadline</th>
    <th>Status</th>
    <th>Actions</th>
  </thead>
  <tbody>
    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
    
    <tr valign='middle'>
      <td><?php echo e($request['request_title']); ?></td>
      <td><?php echo e($request['request_deadline']); ?></td>
      <td><?php echo e($request['status']); ?></td>
      <td>
        <button class="btn btn-warning btn-sm" onclick="fetchQuoteInvoice(<?php echo e($request['request_id']); ?>)" data-bs-toggle="modal" data-bs-target="#QuoteInvoice">View Quote</button>
        <a href="http://127.0.0.1:8000/api/acceptQuote/<?php echo e($request['request_id']); ?>" class="btn btn-success btn-sm">Accept</a>
        <a href="" class="btn btn-danger btn-sm">Reject</a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel project\Paid-Laravel-projects\QKCreators\resources\views/clientQuotes.blade.php ENDPATH**/ ?>