<?php

use App\Mail\QuoteResponseMail;
use App\Mail\SendQuote;
use Illuminate\Support\Facades\Mail;
use App\Models\ClientsQuotes;
use App\Models\ClientRequests;
use Illuminate\Contracts\Session\Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


// Quotes API Routes 
// Show Line Items 
Route::get('/fetch/{id}', function ($id) {

    $AllLineItems = ClientsQuotes::where('request_id', '=', $id)->get();
    $AllLineItems = $AllLineItems->toArray();
    if (!empty($AllLineItems)) {
        $AllLineItems = json_encode($AllLineItems);
        print_r($AllLineItems);
    } else {
        echo 0;
    }
});

// Add Line Item in Database 
Route::get('/addQuotesLineItem/', function (Request $r) {
    if (!empty($r['requestId']) && !empty($r['LineItem']) && !empty($r['Price'])) {
        $newLineItem = new ClientsQuotes;
        $newLineItem->request_id = $r['requestId'];
        $newLineItem->line_items = $r['LineItem'];
        $newLineItem->price = $r['Price'];
        $newLineItem->save();
        echo "1";
    }
});

// Delete Line Item from Database 
Route::get('/DeleteQuotesLineItem/{id}', function ($id) {
    $deleteLineItem = ClientsQuotes::find($id)->delete();
    if ($deleteLineItem) {
        echo 1;
    }
});


// Send Invoice as Mail to the customers  
Route::get('/SendMailInvoice/{id}/{dueDate?}', function ($id, $dueDate = null) {
    if (!empty($dueDate)) {
        $requestDate = ClientRequests::find($id);
        $requestDate->request_deadline = $dueDate;
        $requestDate->save();
    }
    $requestData = ClientRequests::Where('request_id', '=', $id)->get();
    $requestData = $requestData->toArray();
    $c_name = $requestData[0]['client_name'];
    $c_email = $requestData[0]['client_email'];
    $r_title = $requestData[0]['request_title'];
    $r_id = $requestData[0]['request_id'];
    $r_deadline = $requestData[0]['request_deadline'];

    $LineItems = ClientsQuotes::Where('request_id', '=', $id)->get();
    $LineItems = $LineItems->toArray();

    $total = 0;
    foreach ($LineItems as $value) {
        $total += (int)$value['price'];
    }

    $mailData = [
        'client_name' => $c_name,
        'request_title' => $r_title,
        'request_id' => $r_id,
        'request_deadline' => $r_deadline,
        'invoice' => $LineItems,
        'total' => $total
    ];
    Mail::to($c_email)->send(new SendQuote($mailData));

    echo 1;
});




Route::get('/acceptQuote/{id}', function ($id) {
    $requestDate = ClientRequests::find($id);
    if($requestDate->status=="Pending"){
        $clientName=$requestDate->client_name;
        $requestDate->status = "Approved";
        $requestDate->save();
        $data='The quote you sent to <b>'.$clientName.'</b> is <b> approved</b>.You can start working on the project.';
        $mailData=[
            'data'=>$data
        ];
        
        Mail::to('qaisar.qk17@gmail.com')->send(new QuoteResponseMail($mailData,'Accepted'));
        $msg='accept';
        
        return redirect(route('client.quote.response',$msg));
    }else{
        $msg="You cann't be able to Accept Request Quote After Reject Request Quote & After Accepting the Request , you cannot accept it again";
        return redirect(route('client.quote.response',$msg));
    }
});
Route::get('/rejectQuote/{id}', function ($id) {
    $requestDate = ClientRequests::find($id);
    if ($requestDate->status == 'Pending') {
        $clientName=$requestDate->client_name;
        $requestDate->status = "Disapproved";
        $requestDate->save();
        $data='The quote you sent to <b>'.$clientName.'</b> is <b>rejected</b>.';
        $mailData=[
            'data'=>$data
        ];
        
        Mail::to('qaisar.qk17@gmail.com')->send(new QuoteResponseMail($mailData,'Rejected'));
        $msg='reject';
        
        return redirect(route('client.quote.response',$msg));
    }else{
        $msg='You cannot be able to Reject Request After Accepting the request & After Rejecting the request , you cannot reject again';
        
        return redirect(route('client.quote.response',$msg));
    }
});
