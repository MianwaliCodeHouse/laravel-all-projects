@extends('layouts.main')
@push('head')
  <title>Dashboard | Quotes</title>
@endpush
@section('active-tab')
@php
  $quotes='active';
@endphp
@endsection


@section('dynamic-section')
@include('Invoice')
  
<h1 class="h1-responsive mb-3">Quotes</h1>

<table class="table table-striped">
  <thead class="table-dark">
    <th>Request Title</th>
    <th>Request Deadline</th>
    <th>Status</th>
    <th>Actions</th>
  </thead>
  <tbody>
    @foreach ($requests as $request)
      
    
    <tr valign='middle'>
      <td>{{ $request['request_title'] }}</td>
      <td>{{ $request['request_deadline'] }}</td>
      <td>{{ $request['status'] }}</td>
      <td>
        <button class="btn btn-warning btn-sm" onclick="fetchQuoteInvoice({{ $request['request_id'] }})" data-bs-toggle="modal" data-bs-target="#QuoteInvoice">View Quote</button>
        <a href="http://127.0.0.1:8000/api/acceptQuote/{{ $request['request_id'] }}" class="btn btn-success btn-sm">Accept</a>
        <a href="http://127.0.0.1:8000/api/rejectQuote/{{ $request['request_id'] }}" class="btn btn-danger btn-sm">Reject</a>
      </td>
    </tr>
    @endforeach
  </tbody>
</table>



@endsection