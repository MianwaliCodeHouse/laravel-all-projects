<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Accept / Reject</title>
</head>

<body>
    <table width='100%' style="background-color: rgb(245, 235, 255);padding:20px">
      <tr>
        <table style="width: 100%;background-color: #fff;padding:15px">
        <tr style="margin: 10px auto 0;">
            <th width='30%'></th>
            <th>
                <h2>Quote Response</h2>
            </th>
            <th width='30%'></th>
        </tr>
        <tr>
            <td width='30%'></td>
            <td style="text-align: center;padding:10px;">
              <big>
                {!! $mailData['data'] !!}
              </big>
            </td>
            <td width='30%'></td>
        </tr>
      </table>
      </tr>
    </table>
</body>

</html>
