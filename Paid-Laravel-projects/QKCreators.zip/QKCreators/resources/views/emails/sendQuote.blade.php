<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Send Quotes</title>
  <style>
    table,th,td{
padding: 1rem;
text-align: left;
    }
    .card{
      
      border-radius: 5px;
      border: 0.5px solid rgba(0, 0, 0, 0.507);
      width:85% ;
      margin: 1rem auto 0;
      padding: 2rem;
    }
    button{
      padding: 0.5rem 1.2rem;
      border: none;
      border-radius: 5px;
      color: white;
    }
  </style>
</head>
<body>
  <div class="card">
  <p>Name: <b>{{ $mailData['client_name'] }}</b></p>
  <p>Request Title: <b>{{ $mailData['request_title'] }}</b></p>
  <p>Request Deadline: <b> {{ $mailData['request_deadline'] }}</b></p>
  <table style="width: 100%;max-width:800px;margin: 0.5rem auto">
    <tr style="background-color: rgb(9, 49, 212);color:white">
      <th>Sr.No.</th>
      <th>LineItems</th>
      <th>Prices</th>
    </tr>
    @php
      $sr_no=1;
    @endphp
    @foreach ($mailData['invoice'] as $item)
    <tr>
      <td>{{ $sr_no }}</td>
      <td>{{ $item['line_items'] }}</td>
      <td>{{ $item['price'] }}$</td>
    </tr>
    @php
      $sr_no+=1;
    @endphp
    @endforeach
    <tr style="background-color: rgb(8, 158, 8);color:white">
      <th>Total</th>
     
      <th colspan="2">{{ $mailData['total'] }}$</th>
    </tr>
  </table>
  <p><big>You can Accept Quotes to Start Job and also can Reject Quotes to Cancel Project Request</big></p>
  <div>
    <a href="http://127.0.0.1:8000/api/acceptQuote/{{ $mailData['request_id'] }}"><button style="background-color: rgb(25, 187, 25)">Accept</button></a>
    <a href="http://127.0.0.1:8000/api/rejectQuote/{{ $mailData['request_id'] }}"><button style="background-color: rgb(212, 29, 29)">Reject</button></a>
  </div>
</div>
  <br>
  <br>
  <br>
  <br>
  <br>
</body>
</html>