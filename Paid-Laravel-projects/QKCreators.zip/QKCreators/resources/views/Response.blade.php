<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bootstrap 5 Thank You Example</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>

    <body>
 
      <div class="vh-100 d-flex justify-content-center align-items-center">
            <div class="card col-md-4 bg-white shadow-md p-5">
              
                  
              
                <div class="mb-4 text-center">
                  @if ($data=='accept')
                      
                  <svg xmlns="http://www.w3.org/2000/svg" class="text-success" width="75" height="75"
                      fill="currentColor" class="bi bi-check-circle" viewBox="0 0 16 16">
                      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                      <path
                          d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z" />
                  </svg>
                  @elseif ($data=='reject')
                  <svg style="color: red" xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 16 16" width="80" height="80" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"> <path d="m10.25 5.75-4.5 4.5m0-4.5 4.5 4.5" fill="red"></path> <circle cx="8" cy="8" r="6.25"></circle> </svg>
                  @elseif (!empty($data))
                  <svg style="color: red" xmlns="http://www.w3.org/2000/svg" width="75" height="75" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-alert-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                  @endif
                </div>
                
                <div class="text-center">
@if ($data=='accept')
<h1>Accepted Successfully !</h1>
<p>Now , Your Request has been Approved and We will contact you to start your Project. </p>
<a href="{{ route('client.home') }}">
  <button class="btn btn-success">Go To Dashboard</button>
  </a>
@elseif ($data=='reject')
<h1>Rejected Successfully !</h1>
<p>Now , Your Request has been Disapproved. </p>
<a href="{{ route('client.home') }}">
<button class="btn btn-success">Go To Dashboard</button>
</a>
@elseif (!empty($data))
<h1 class="mb-3">Sorry!</h1>
<p>{{ $data }}</p>
@endif
                    
                </div>
            </div>
    </body>

</html> 