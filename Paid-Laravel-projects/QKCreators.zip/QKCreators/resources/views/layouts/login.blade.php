@include('layouts.header')

@yield('main-section')

@include('layouts.footer')