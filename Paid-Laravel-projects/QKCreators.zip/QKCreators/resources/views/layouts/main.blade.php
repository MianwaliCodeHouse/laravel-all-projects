@include('layouts.header')

@include('layouts.common')

@include('layouts.footer')