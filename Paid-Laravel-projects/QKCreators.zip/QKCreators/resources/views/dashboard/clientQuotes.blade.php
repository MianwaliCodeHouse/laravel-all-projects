  
@extends('dashboard.layouts.main')
@push('head')
  <title>Dashboard | Quotes</title>
@endpush
@section('active-tab')
@php
    $quotes='active';
@endphp
@endsection

@section('dynamic-section')
  
@include('dashboard.invoice')
  
<h1 class="h1-responsive mb-3">Quotes</h1>

<table class="table table-striped">
  <thead class="table-dark">
    <th>Client Name</th>
    <th>Request Title</th>
    <th>Request Deadline</th>
    <th>Status</th>
    <th>Actions</th>
  </thead>
  <tbody>
    @foreach ($requests as $request)
      
    
    <tr valign='middle'>
      <td>{{ $request['client_name'] }}</td>
      <td>{{ $request['request_title'] }}</td>
      <td>{{ $request['request_deadline'] }}</td>
      <td>{{ $request['status'] }}</td>
      <td>
        <button class="btn btn-warning btn-sm" onclick="fetchQuoteInvoice({{ $request['request_id'] }})" data-bs-toggle="modal" data-bs-target="#QuoteInvoice">View Quote</button>
        
      </td>
    </tr>
    @endforeach
  </tbody>
</table>





@endsection
