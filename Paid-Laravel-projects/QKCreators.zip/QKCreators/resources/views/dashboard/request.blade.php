@extends('dashboard.layouts.main')
@push('head')
  <title>Dashboard | Home</title>
@endpush

@section('active-tab')
@php
  $requestRoute='active';
@endphp
@endsection

@section('dynamic-section')
  

{{-- Requests Requirements Models  --}}
@foreach ($AllRequests as $Request )

<!-- Modal -->
<div class="modal fade" id="requirements{{ $Request['request_id'] }}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Requirements</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        {{ $Request['request_requirements'] }}
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>

@endforeach


{{-- Requests Attachments Files Models  --}}
@foreach ($AllRequests as $Request )

<!-- Modal -->
<div class="modal fade" id="attachments{{ $Request['request_id'] }}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Attachments</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        @php
          $attachments=$Request['attachments'];
          $attachments=explode(',,,',$attachments);
          array_pop($attachments);
        @endphp
        @foreach ($attachments as $key=>$value)
          <div class="h6">Document {{ $key }}</div>
          <a href="" class="mb-4 d-block">{{ $value }}</a>
        @endforeach
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

@endforeach

{{-- Quotes Builder  --}}
@include('dashboard.quotes_builder')

<div class="h1 mt-3 mb-3">Requests</div>
<div class="table-reponsive">
<table class="table table-hover w-sm-100">
  <thead class="table-dark">
  <tr>
    <th>Client Name</th>
    <th>Title</th>
    <th>DeadLine</th>
    <th>Project Type</th>
    <th>Requirements</th>
    <th>Attachments</th>
    <th>Status</th>
    <th>Actions</th>
  </tr>
</thead>
@foreach ($AllRequests as $Request )

<tr valign='middle'>
  <td>{{ $Request['client_name'] }}</td>
  <td>{{ $Request['request_title'] }}</td>
  <td>{{ $Request['request_deadline'] }}</td>
  <td>{{ $Request['project_type'] }}</td>
  <td><button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#requirements{{ $Request['request_id'] }}">Requirements</button></td>
  <td><button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#attachments{{ $Request['request_id'] }}">Attachments</button></td>
  <td><span class="bg-warning rounded px-2 py-1 d-inline-block">{{ $Request['status'] }}</span></td>
  <td>
    <button class="btn btn-success btn-sm">View</button>
    <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#quotes_builder" onclick="document.querySelector('#request_id').value={{ $Request['request_id'] }};fetchLineItems(request_id.value);">Quotes</button>
    <button class="btn btn-success btn-sm">Job</button>
    <button class="btn btn-danger btn-sm">Reject</button>
  </td>
</tr>

@endforeach
  
</table>
</div>

@endsection
