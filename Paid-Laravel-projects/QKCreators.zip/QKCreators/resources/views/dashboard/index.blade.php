@extends('dashboard.layouts.main')
@push('head')
  <title>Dashboard | Home</title>
@endpush
@section('active-tab')
@php
  $home='active';
@endphp
@endsection

@section('dynamic-section')
  
@endsection
