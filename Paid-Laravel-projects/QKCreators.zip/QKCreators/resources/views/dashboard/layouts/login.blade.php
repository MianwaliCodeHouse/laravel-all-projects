@include('dashboard.layouts.header')

@yield("main-section")

@include('dashboard.layouts.footer')