@include('layouts.header')

@include('dashboard.layouts.common')

@include('layouts.footer')