<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Mail\Mailables\Attachment;

// Include Mail 
use Illuminate\Support\Facades\Mail;
// Client Request Send Mail to Admin 
use App\Mail\RequestClentToAdmin;


// Client Request Model 
use App\Models\ClientRequests;
use App\Models\ClientsQuotes;

class ClientsController extends Controller
{
    public function index()
    {
        return view('index');
    }
    public function logout()
    {
        session()->flush();
        return redirect(route('client.login.page'));
    }
    public function requestPage()
    {
        return view('createRequest');
    }
    public function request(Request $r)
    {
        $r->validate(
            [
                'request_title' => 'required',
                'request_requirements' => 'required',
                'project_type' => 'required',
            ]
        );

        $createRequest = new ClientRequests;
        $createRequest->request_title = $r['request_title'];
        $createRequest->request_requirements = $r['request_requirements'];
        $createRequest->project_type = $r['project_type'];
        $createRequest->status = 'Pending';
        if (!empty($r['request_deadline'])) {
            $createRequest->request_deadline = $r['request_deadline'];
            
        }
        if (!empty($r['request_budget'])) {
            $createRequest->request_budget = $r['request_budget'];
            
        }


        // upload Attachments 
        if ($r->file('attachments')) {
            $attachments = '';
            foreach ($r->file('attachments') as $key => $file) {
                $filename = $file->getClientOriginalName();
                $newName = time() . $filename;
                $file->move(public_path().'/uploads/Attachments',$newName);
                $attachments .= $newName . ',,,';
            }
            $createRequest->attachments=$attachments;
            

        }
        
        $RequestClientName=session()->get('ClientName');
        $clientEmail=session()->get('clientEmail');
        
        $createRequest->client_email=$clientEmail;
        $createRequest->client_name=$RequestClientName;

        $createRequest->save();
        
        $mailData=[
            'name'=>$RequestClientName,
            'requestTitle'=>$r['request_title'],
            'requestRequirements'=>$r['request_requirements'],
        ];
        Mail::to('qaisar.qk17@gmail.com')->send(new RequestClentToAdmin($mailData));
        session()->flash('ClientRequestSent','Your Request has successfully Send and Also Sent Email to the Admin');
        return redirect(route('client.request.form'));

    }

    public function showRequest(){
        $AllRequests=ClientRequests::all();
        $AllRequests=$AllRequests->toArray();
        $data=compact('AllRequests');
        return view('requests')->with($data);
    }
    public function quoteResponse($data){
        $data=compact('data');
        return view('Response')->with($data);
    }
    public function quoteDisplay(){
        $c_email=session()->get('clientEmail');
        $AllRequests=ClientRequests::where('client_email',$c_email)->get();
        $check=$AllRequests->toArray();
        $requests=array();
        if(!empty($check)){
            foreach ($check as $key => $value) {
                $id=$value['request_id'];
                $checkInQuote=ClientsQuotes::Where('request_id',$id)->first();
                if($checkInQuote){
                    array_push($requests,$value);
                }
            }
        }

        $data=compact('requests');        
        return view('clientQuotes')->with($data);
    }
     
}
